const CATEGORIES = [
  "All",
  "Companies",
  "Markets",
  "Finance",
  "Startups",
  "Technology & AI",
  "Economy",
  "Investments",
  "M&A",
];

export default function CategoryFilter({ active, onChange }) {
  return (
    <div className="flex flex-wrap gap-2">
      {CATEGORIES.map((cat) => (
        <button
          key={cat}
          onClick={() => onChange(cat)}
          className={`rounded-full border px-3 py-1.5 text-sm transition-colors ${
            active === cat
              ? "border-accent bg-accent text-paper"
              : "hairline text-ink/70 hover:border-accent/50 dark:text-paper/70"
          }`}
        >
          {cat}
        </button>
      ))}
    </div>
  );
}
