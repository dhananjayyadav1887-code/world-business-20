export default function SearchBar({ value, onChange }) {
  return (
    <div className="hairline flex items-center gap-2 rounded-full border px-4 py-2">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="shrink-0 text-ink/50 dark:text-paper/50">
        <circle cx="11" cy="11" r="7" />
        <path d="M21 21l-4.3-4.3" />
      </svg>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search by company, person, or topic"
        className="w-full bg-transparent text-sm outline-none placeholder:text-ink/40 dark:placeholder:text-paper/40"
      />
    </div>
  );
}
