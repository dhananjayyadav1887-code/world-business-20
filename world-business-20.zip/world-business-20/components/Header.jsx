"use client";

import ThemeToggle from "./ThemeToggle";

export default function Header({ generatedAt, totalStories, refreshing }) {
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const lastUpdated = generatedAt
    ? new Date(generatedAt).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
    : "—";

  return (
    <header className="hairline sticky top-0 z-20 border-b bg-paper/90 backdrop-blur dark:bg-ink/90">
      <div className="mx-auto max-w-5xl px-5 py-5">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="font-serif text-3xl font-700 tracking-tight sm:text-4xl">
              World Business 20
            </h1>
            <p className="mt-1 max-w-md text-sm text-ink/70 dark:text-paper/70">
              The 20 most important business stories around the world — updated daily.
            </p>
          </div>
          <ThemeToggle />
        </div>

        <div className="hairline mt-4 flex flex-wrap items-center gap-x-5 gap-y-1 border-t pt-3 text-xs text-ink/60 dark:text-paper/60">
          <span>{today}</span>
          <span className="rank-num">Top {totalStories || 20} global business stories</span>
          <span>Last updated {lastUpdated}</span>
          <span className="flex items-center gap-1.5">
            <span
              className={`h-1.5 w-1.5 rounded-full ${
                refreshing ? "bg-accent animate-pulse" : "bg-rise"
              }`}
            />
            {refreshing ? "Refreshing…" : "Up to date"}
          </span>
        </div>
      </div>
    </header>
  );
}
