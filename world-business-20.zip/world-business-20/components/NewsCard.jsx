const BADGE_STYLES = {
  Breaking: "bg-fall/10 text-fall",
  Major: "bg-accent/10 text-accent",
  Trending: "bg-rise/10 text-rise",
};

export default function NewsCard({ article }) {
  const time = new Date(article.publishedAt).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <article className="hairline group grid grid-cols-[auto_1fr] gap-4 border-b py-6 first:pt-0 last:border-b-0">
      <span className="font-serif text-4xl leading-none text-accent rank-num">
        {String(article.rank).padStart(2, "0")}
      </span>

      <div className="min-w-0">
        <div className="mb-1.5 flex flex-wrap items-center gap-2 text-xs text-ink/60 dark:text-paper/60">
          <span className="hairline rounded-full border px-2 py-0.5">{article.category}</span>
          {article.badge && (
            <span className={`rounded-full px-2 py-0.5 font-medium ${BADGE_STYLES[article.badge] || ""}`}>
              {article.badge}
            </span>
          )}
          <span>{time}</span>
        </div>

        <h2 className="font-serif text-xl font-600 leading-snug sm:text-2xl">{article.headline}</h2>

        <p className="mt-2 text-[15px] leading-relaxed text-ink/80 dark:text-paper/80">
          {article.summary}
        </p>

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <span className="text-sm text-ink/60 dark:text-paper/60">Source: {article.sourceName}</span>
          <a
            href={article.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-sm font-medium text-accent underline decoration-accent/40 underline-offset-4 transition-colors hover:decoration-accent"
          >
            Read original source
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M7 17L17 7M7 7h10v10" />
            </svg>
          </a>
        </div>
      </div>
    </article>
  );
}
