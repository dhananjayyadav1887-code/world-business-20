export default function DateSelector({ dates, selected, onChange }) {
  if (!dates || dates.length <= 1) return null;

  return (
    <select
      value={selected || ""}
      onChange={(e) => onChange(e.target.value)}
      className="hairline rounded-full border bg-transparent px-3 py-1.5 text-sm outline-none"
    >
      {dates.map((d) => (
        <option key={d.date} value={d.date} className="text-ink">
          {new Date(d.date + "T00:00:00").toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
          })}
        </option>
      ))}
    </select>
  );
}
