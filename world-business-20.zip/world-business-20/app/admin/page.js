"use client";

import { useState } from "react";

export default function AdminPage() {
  const [secret, setSecret] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [data, setData] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  async function loadStatus(key) {
    setError(null);
    const res = await fetch("/api/admin/status", { headers: { "x-admin-secret": key } });
    if (res.status === 401) {
      setError("Incorrect admin key.");
      setUnlocked(false);
      return;
    }
    const json = await res.json();
    setData(json);
    setUnlocked(true);
  }

  async function triggerRefresh() {
    setRefreshing(true);
    setError(null);
    try {
      const res = await fetch("/api/cron/refresh", {
        method: "POST",
        headers: { "x-cron-secret": secret },
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Refresh failed");
      await loadStatus(secret);
    } catch (e) {
      setError(e.message);
    } finally {
      setRefreshing(false);
    }
  }

  if (!unlocked) {
    return (
      <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-5">
        <h1 className="font-serif text-2xl">Admin access</h1>
        <p className="mt-1 text-sm text-ink/60">Enter the admin key from your environment variables.</p>
        <form
          className="mt-4 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            loadStatus(secret);
          }}
        >
          <input
            type="password"
            value={secret}
            onChange={(e) => setSecret(e.target.value)}
            className="hairline flex-1 rounded-md border bg-transparent px-3 py-2 text-sm outline-none"
            placeholder="ADMIN_SECRET"
          />
          <button className="rounded-md bg-accent px-4 py-2 text-sm font-medium text-paper">
            Enter
          </button>
        </form>
        {error && <p className="mt-3 text-sm text-fall">{error}</p>}
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-2xl px-5 py-10">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="font-serif text-2xl">Admin — News Pipeline</h1>
        <button
          onClick={triggerRefresh}
          disabled={refreshing}
          className="rounded-md bg-accent px-4 py-2 text-sm font-medium text-paper disabled:opacity-50"
        >
          {refreshing ? "Refreshing…" : "Trigger manual refresh"}
        </button>
      </div>

      {error && <p className="mb-4 text-sm text-fall">{error}</p>}

      {data?.latestDigest && (
        <section className="hairline mb-8 rounded-lg border p-4">
          <h2 className="mb-2 font-medium">
            Latest digest — {data.latestDigest.date} ({data.latestDigest.articles.length} articles)
          </h2>
          <ol className="space-y-1 text-sm">
            {data.latestDigest.articles.map((a) => (
              <li key={a.rank} className="truncate">
                <span className="text-accent">#{a.rank}</span> {a.headline}{" "}
                <span className="text-ink/50">— {a.sourceName}</span>
              </li>
            ))}
          </ol>
        </section>
      )}

      <section>
        <h2 className="mb-2 font-medium">Refresh log</h2>
        <div className="hairline divide-y rounded-lg border">
          {(data?.logs || []).map((log) => (
            <div key={log.id} className="flex items-center justify-between px-4 py-2 text-sm">
              <span>{new Date(log.startedAt).toLocaleString()}</span>
              <span
                className={
                  log.status === "success"
                    ? "text-rise"
                    : log.status === "error"
                    ? "text-fall"
                    : "text-accent"
                }
              >
                {log.status}
              </span>
              <span className="text-ink/60">
                {log.fetchedCount} fetched → {log.selectedCount} selected
              </span>
            </div>
          ))}
          {(!data?.logs || data.logs.length === 0) && (
            <p className="px-4 py-6 text-center text-sm text-ink/50">No refresh runs yet.</p>
          )}
        </div>
        {data?.logs?.some((l) => l.errorMessage) && (
          <div className="mt-3 space-y-1 text-xs text-fall">
            {data.logs
              .filter((l) => l.errorMessage)
              .map((l) => (
                <p key={l.id}>{l.errorMessage}</p>
              ))}
          </div>
        )}
      </section>
    </main>
  );
}
