"use client";

import { useEffect, useMemo, useState } from "react";
import Header from "@/components/Header";
import NewsCard from "@/components/NewsCard";
import CategoryFilter from "@/components/CategoryFilter";
import SearchBar from "@/components/SearchBar";
import DateSelector from "@/components/DateSelector";

export default function Home() {
  const [digest, setDigest] = useState(null);
  const [dates, setDates] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("loading"); // loading | ready | error | empty

  useEffect(() => {
    fetch("/api/news/history")
      .then((r) => r.json())
      .then((d) => setDates(d.dates || []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    setStatus("loading");
    const url = selectedDate ? `/api/news?date=${selectedDate}` : "/api/news";
    fetch(url)
      .then((r) => r.json())
      .then((d) => {
        if (!d.digest) {
          setDigest(null);
          setStatus("empty");
        } else {
          setDigest(d.digest);
          setStatus("ready");
        }
      })
      .catch(() => setStatus("error"));
  }, [selectedDate]);

  const filtered = useMemo(() => {
    if (!digest) return [];
    const q = query.trim().toLowerCase();
    return digest.articles.filter((a) => {
      const matchesCategory = category === "All" || a.category === category;
      const matchesQuery =
        !q ||
        a.headline.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q) ||
        a.sourceName.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [digest, category, query]);

  return (
    <main className="min-h-screen">
      <Header generatedAt={digest?.generatedAt} totalStories={digest?.articles?.length} />

      <div className="mx-auto max-w-5xl px-5 py-6">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <CategoryFilter active={category} onChange={setCategory} />
          <div className="flex items-center gap-3">
            <DateSelector dates={dates} selected={selectedDate || digest?.date} onChange={setSelectedDate} />
          </div>
        </div>

        <div className="mb-6">
          <SearchBar value={query} onChange={setQuery} />
        </div>

        {status === "loading" && (
          <div className="space-y-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="hairline animate-pulse border-b py-6">
                <div className="mb-3 h-3 w-24 rounded bg-ink/10 dark:bg-paper/10" />
                <div className="mb-2 h-6 w-3/4 rounded bg-ink/10 dark:bg-paper/10" />
                <div className="h-4 w-full rounded bg-ink/10 dark:bg-paper/10" />
              </div>
            ))}
          </div>
        )}

        {status === "error" && (
          <div className="hairline rounded-lg border py-16 text-center">
            <p className="font-serif text-lg">Couldn't load today's stories.</p>
            <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">
              Check your connection and try again.
            </p>
          </div>
        )}

        {status === "empty" && (
          <div className="hairline rounded-lg border py-16 text-center">
            <p className="font-serif text-lg">No digest yet for this date.</p>
            <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">
              An admin needs to trigger the first refresh from <code>/admin</code>.
            </p>
          </div>
        )}

        {status === "ready" && filtered.length === 0 && (
          <div className="hairline rounded-lg border py-16 text-center">
            <p className="font-serif text-lg">No stories match your filters.</p>
            <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">
              Try a different category or search term.
            </p>
          </div>
        )}

        {status === "ready" && filtered.length > 0 && (
          <div>
            {filtered.map((article) => (
              <NewsCard key={article.id} article={article} />
            ))}
          </div>
        )}
      </div>

      <footer className="hairline border-t py-8 text-center text-xs text-ink/50 dark:text-paper/50">
        Summaries are generated from original reporting. Always verify against the linked source.
      </footer>
    </main>
  );
}
