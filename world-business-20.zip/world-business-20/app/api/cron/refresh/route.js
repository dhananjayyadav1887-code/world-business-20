import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { fetchAllRaw, normalizeKey } from "@/lib/newsSource";
import { dedupe } from "@/lib/dedupe";
import { rankAndSelect } from "@/lib/rank";

export const maxDuration = 60; // seconds, for the Vercel serverless function

function todayISO() {
  return new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"
}

function isAuthorized(request) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;

  // Vercel Cron sends this automatically on scheduled invocations.
  const cronHeader = request.headers.get("authorization");
  if (cronHeader === `Bearer ${secret}`) return true;

  // Manual trigger from the admin page sends the same secret this way.
  const manualHeader = request.headers.get("x-cron-secret");
  return manualHeader === secret;
}

async function runRefresh() {
  const log = await prisma.refreshLog.create({
    data: { status: "running" },
  });

  try {
    const { articles: raw, errors } = await fetchAllRaw();

    const cleaned = raw
      .filter((a) => a.headline && a.sourceUrl && a.summary)
      .map((a) => ({ ...a, dedupeKey: normalizeKey(a.headline, a.sourceName) }));

    const deduped = dedupe(cleaned);
    const top20 = rankAndSelect(deduped, 20);

    if (top20.length === 0) {
      throw new Error(
        `No usable articles after filtering (fetched ${raw.length} raw). ` +
          (errors.length ? `Provider errors: ${errors.join(" | ")}` : "Check API keys.")
      );
    }

    const date = todayISO();

    // Upsert today's digest: wipe previous articles for today (in case of a
    // manual re-refresh) and replace with the fresh Top 20.
    const digest = await prisma.dailyDigest.upsert({
      where: { date },
      update: { generatedAt: new Date() },
      create: { date },
    });

    await prisma.article.deleteMany({ where: { digestId: digest.id } });
    await prisma.article.createMany({
      data: top20.map((a) => ({
        digestId: digest.id,
        rank: a.rank,
        headline: a.headline,
        summary: a.summary,
        category: a.category,
        sourceName: a.sourceName,
        sourceUrl: a.sourceUrl,
        imageUrl: a.imageUrl,
        publishedAt: a.publishedAt,
        badge: a.badge,
        score: a.score,
        dedupeKey: a.dedupeKey,
      })),
    });

    await prisma.refreshLog.update({
      where: { id: log.id },
      data: {
        status: errors.length ? "success" : "success",
        finishedAt: new Date(),
        fetchedCount: raw.length,
        selectedCount: top20.length,
        errorMessage: errors.length ? `Non-fatal provider issues: ${errors.join(" | ")}` : null,
      },
    });

    return { ok: true, fetched: raw.length, selected: top20.length, date };
  } catch (err) {
    await prisma.refreshLog.update({
      where: { id: log.id },
      data: { status: "error", finishedAt: new Date(), errorMessage: String(err.message || err) },
    });
    throw err;
  }
}

export async function GET(request) {
  // Vercel Cron issues GET requests on schedule.
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const result = await runRefresh();
    return NextResponse.json(result);
  } catch (err) {
    console.error("Refresh failed:", err);
    return NextResponse.json({ error: String(err.message || err) }, { status: 500 });
  }
}

export async function POST(request) {
  // Manual trigger from the admin page.
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const result = await runRefresh();
    return NextResponse.json(result);
  } catch (err) {
    console.error("Refresh failed:", err);
    return NextResponse.json({ error: String(err.message || err) }, { status: 500 });
  }
}
