import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

function isAuthorized(request) {
  const secret = process.env.ADMIN_SECRET;
  if (!secret) return false;
  const header = request.headers.get("x-admin-secret");
  return header === secret;
}

export async function GET(request) {
  if (!isAuthorized(request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const logs = await prisma.refreshLog.findMany({
    orderBy: { startedAt: "desc" },
    take: 15,
  });

  const latestDigest = await prisma.dailyDigest.findFirst({
    orderBy: { date: "desc" },
    include: { articles: { orderBy: { rank: "asc" }, select: { rank: true, headline: true, sourceName: true } } },
  });

  return NextResponse.json({ logs, latestDigest });
}
