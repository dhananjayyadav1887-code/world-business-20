import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/news            -> latest digest
// GET /api/news?date=2026-09-14 -> that day's digest (if stored)
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const date = searchParams.get("date");

    const digest = date
      ? await prisma.dailyDigest.findUnique({
          where: { date },
          include: { articles: { orderBy: { rank: "asc" } } },
        })
      : await prisma.dailyDigest.findFirst({
          orderBy: { date: "desc" },
          include: { articles: { orderBy: { rank: "asc" } } },
        });

    if (!digest) {
      return NextResponse.json(
        { digest: null, message: "No digest available yet. Trigger a refresh from /admin." },
        { status: 200 }
      );
    }

    return NextResponse.json({ digest });
  } catch (err) {
    console.error("GET /api/news failed:", err);
    return NextResponse.json({ error: "Failed to load news." }, { status: 500 });
  }
}
