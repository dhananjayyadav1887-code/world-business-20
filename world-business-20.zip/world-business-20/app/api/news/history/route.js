import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/news/history -> last 30 dates that have a stored digest
export async function GET() {
  try {
    const digests = await prisma.dailyDigest.findMany({
      orderBy: { date: "desc" },
      take: 30,
      select: { date: true, generatedAt: true },
    });
    return NextResponse.json({ dates: digests });
  } catch (err) {
    console.error("GET /api/news/history failed:", err);
    return NextResponse.json({ error: "Failed to load history." }, { status: 500 });
  }
}
