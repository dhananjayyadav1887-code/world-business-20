/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#F7E8DD",      // warm pink-tan, nods to financial-press newsprint
        paperdim: "#EFDCCC",
        ink: "#12202E",        // deep navy — primary text / dark-mode background
        inkdim: "#22344A",
        accent: "#A8720A",     // brass/gold — rank numerals, highlights
        rise: "#1F6F5C",       // deep teal-green — positive/market-up signal
        fall: "#9C3B32",       // brick red — negative/market-down signal
        line: "#D9C4B0",       // hairline rule on paper
        linedark: "#324357",   // hairline rule on ink
      },
      fontFamily: {
        serif: ["'Source Serif 4'", "Georgia", "serif"],
        sans: ["Inter", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
